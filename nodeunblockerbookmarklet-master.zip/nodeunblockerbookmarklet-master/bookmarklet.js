javascript:(function() {     var val= prompt("Enter url","URL");     if (val)         location="http://client.esser.ga"+"/textbooks/"+escape(val);})()
