this is a node unblocker bookmarklet made by Jamen Noodles#3743
 
add to your bookmarks bar and press it on a website then enter your url and it will open that url unblocked
 
enjoy :)
